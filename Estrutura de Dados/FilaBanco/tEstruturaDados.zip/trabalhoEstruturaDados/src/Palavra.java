import javax.swing.*;
import java.io.Serializable;
import java.util.Objects;
import java.util.jar.JarOutputStream;

public class Palavra implements Serializable {
    private String palavra = "";
    private int tamanho;

    public Palavra(String palavra) {
        this.palavra = palavra;
        this.tamanho = palavra.length();
    }
    public int getTamanho() {
        return palavra.length();
    }

    public String getPalavra() {
        return palavra;
    }

    public boolean comparaLetra(String l) {
        return this.palavra.charAt(0) == l.charAt(0);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Palavra palavra1 = (Palavra) o;
        return Objects.equals(palavra, palavra1.palavra);
    }

    @Override
    public String toString() {
        return palavra;
    }
}
