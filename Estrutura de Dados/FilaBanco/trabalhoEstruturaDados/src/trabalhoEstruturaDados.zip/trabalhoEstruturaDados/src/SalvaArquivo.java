import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class SalvaArquivo {
    public void grava (Object ob) {
        try {
            File arquivo = arquivo = new File("src/texto/de.txt");
            ObjectOutputStream grava = new ObjectOutputStream(new FileOutputStream(arquivo));
            grava.writeObject(ob);
            grava.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Object ler() {
        Object retorno = null;

        try {
            FileInputStream arquivo = new FileInputStream("src/texto/de.txt");
            ObjectInputStream ler = new ObjectInputStream(arquivo);

            Object obj = (Object) ler.readObject();
            if (obj != null){
                retorno = obj;
            }

            arquivo.close();
            ler.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();

        }
        return retorno;
    }
}
